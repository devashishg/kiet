import { BetterhighlightDirective } from './betterhighlight.directive';

describe('BetterhighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new BetterhighlightDirective();
    expect(directive).toBeTruthy();
  });
});
