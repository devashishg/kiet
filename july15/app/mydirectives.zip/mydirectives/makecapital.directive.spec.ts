import { MakecapitalDirective } from './makecapital.directive';

describe('MakecapitalDirective', () => {
  it('should create an instance', () => {
    const directive = new MakecapitalDirective();
    expect(directive).toBeTruthy();
  });
});
